export const actionType = {
  INCREMENT: "INCREMENT",
  DECREMENT: "DECREMENT",
  MULTIPLY: "MULTIPLY",
  DIVIDE: "DIVIDE"
};
