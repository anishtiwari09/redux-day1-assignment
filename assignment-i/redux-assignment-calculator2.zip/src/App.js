import MathmaticalOperation from "./component/counter";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <h1>Mathmatical Operation</h1>

      <MathmaticalOperation />
    </div>
  );
}
